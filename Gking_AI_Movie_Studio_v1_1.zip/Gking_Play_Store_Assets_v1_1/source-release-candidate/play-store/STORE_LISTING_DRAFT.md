# Google Play Store listing draft

**App name:** Gking AI Movie Studio

**Short description:** Turn story ideas into screenplays, characters, cinematic images and AI video scenes.

**Full description:**
Gking AI Movie Studio helps storytellers plan and develop movie projects in one workspace. Build projects across genres, draft screenplay treatments, design reusable character profiles, create concept images, generate short video scenes with supported providers, and produce spoken narration. When the server is configured with FFmpeg, Gking can assemble completed video clips into an MP4.

Features depend on provider availability and your account's configured AI services. AI generation can take time and may incur usage charges. Generated characters may not look identical across every scene. The current renderer assembles clips in creation order and does not yet offer a professional drag-and-drop timeline, transitions, subtitles or full audio mixing.

**Support email:** Replace with an email you control before submission.
**Privacy policy:** Replace with a publicly accessible privacy policy URL before submission.
**Website:** Replace with your deployed website URL.
