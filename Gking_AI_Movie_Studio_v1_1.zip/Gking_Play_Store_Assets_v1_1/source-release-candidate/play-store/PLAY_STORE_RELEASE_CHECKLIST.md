# Google Play release checklist — Gking AI Movie Studio

## This package is source code, not a published Play Store app
The Android wrapper needs a real HTTPS deployment URL and must be built and signed with your own Android/Play Console credentials. This workspace cannot upload it to your Play Console.

## Required before release
- [ ] Deploy the Node.js backend and web UI to a stable HTTPS domain.
- [ ] Configure managed database, persistent private file storage, backups, monitoring, queue workers, rate limits and API cost limits.
- [ ] Edit `public/app-config.js` and set `window.GKING_API_BASE` to your deployed HTTPS backend origin before building.
- [ ] Run `npm install`, `npm run android:add` (first time), then `npm run android:sync`.
- [ ] Open Android Studio; test on real devices and current Android versions.
- [ ] Configure app icon, splash screen, version code/name, application ID and release signing key. Keep the signing key private and backed up.
- [ ] Build a signed Android App Bundle (.aab) in Android Studio.
- [ ] Complete Play Console app access, store listing, screenshots, content rating, target audience, ads declaration, data safety form, privacy policy URL, external account-deletion request URL (`/delete-account.html`), account deletion process, and testing track requirements.
- [ ] Test account registration/login, project privacy, AI errors, network loss, video playback/download, account deletion, API cost controls, and billing before release.
- [ ] Publish through Play Console after Google's review.

## Data & AI disclosures
The app sends user prompts and selected media to whichever AI providers the operator configures. Explain this clearly in the privacy policy and in-app notices. Do not claim offline AI generation. Do not launch paid credits until payment, receipts, refunds, abuse prevention and platform billing compliance are implemented.

## Important architecture note
The Android app is a Capacitor wrapper for the hosted web app. The Express/SQLite backend runs on a server, not inside the Android app. Replace the placeholder server URL before building. Use a managed production database instead of local SQLite for a public multi-instance launch.
