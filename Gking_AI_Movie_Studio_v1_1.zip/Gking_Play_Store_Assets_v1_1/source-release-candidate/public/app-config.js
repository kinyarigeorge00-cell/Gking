/* Web deployment: leave empty to use the same origin.
   Android build: replace with your deployed API origin, e.g. https://api.gkingstudio.com
   Do not put AI provider API keys in this file. */
window.GKING_API_BASE = "";
