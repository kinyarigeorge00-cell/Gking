# Gking Ultimate AI Movie Studio — v1.0 Release Candidate

This package combines the earlier screenplay, image, short-video and Character Studio work and adds an OpenAI speech adapter, a first FFmpeg clip assembler, a timeline/export screen, PWA shell files and a Capacitor Android wrapper source configuration.

## Current functional scope
- Accounts, private projects and character profiles.
- OpenAI screenplay adapter (`TEXT_PROVIDER=openai`).
- OpenAI still-image adapter (`IMAGE_PROVIDER=openai`).
- Google Gemini short-video adapter (`VIDEO_PROVIDER=google`), subject to valid model/API access.
- OpenAI speech narration/dialogue (`AUDIO_PROVIDER=openai`). It is spoken audio, not music generation.
- FFmpeg assembly of completed video clips in creation order (`RENDER_PROVIDER=ffmpeg`). It produces a basic joined MP4 without transitions, subtitles, music mixing or timeline trimming.
- Responsive web UI and basic PWA shell.
- Capacitor configuration for an Android app wrapper.

## Run the backend locally
1. Install Node.js 20+ and FFmpeg if you want movie assembly.
2. Copy `.env.example` to `.env`.
3. Set a unique `JWT_SECRET` with at least 32 random characters. Set `CORS_ORIGINS` to your deployed web origin (comma-separated if needed); Capacitor localhost origins are allowed by default.
4. Run `npm install`.
5. Configure API keys and provider names only when you are ready for paid live generation.
6. Run `npm start`, then open `http://localhost:3000`.

### Provider settings
- Screenplay: `TEXT_PROVIDER=openai`, `OPENAI_API_KEY`, `OPENAI_TEXT_MODEL` set to a model enabled for your API account.
- Images: `IMAGE_PROVIDER=openai`, `OPENAI_API_KEY`, `OPENAI_IMAGE_MODEL` set to an image model enabled for your account.
- Video: `VIDEO_PROVIDER=google`, `GOOGLE_API_KEY`, `GOOGLE_VIDEO_MODEL` set to a currently supported model enabled for your account.
- Spoken narration: `AUDIO_PROVIDER=openai`, `OPENAI_API_KEY`, `OPENAI_TTS_MODEL`. Use the Production Lab task type `Voice / music` and enter the text to speak. This implementation generates speech only, not music.
- Clip assembly: `RENDER_PROVIDER=ffmpeg`; install FFmpeg on the server. Select `Movie render` in Production Lab or use Movie Timeline. It joins completed generated clips by creation time.

Provider names/models and API availability can change. Confirm the model names in the provider account's current documentation. Never put API keys in frontend code or a mobile binary.

## Android / Google Play path
The backend must first be deployed to a stable HTTPS domain. This package includes `capacitor.config.ts` and Play Store listing/checklist drafts. The Android wrapper points at the hosted app, because Express, SQLite and AI jobs run on a server rather than inside Android.

After deploying the backend, configure `GKING_SERVER_URL` with the HTTPS origin, then run:

```bash
npm install
npm run android:add   # first time only
npm run android:sync
npm run android:open
```

Build a signed Android App Bundle (.aab) from Android Studio and upload it yourself to your Google Play Console. The app is not published and this package is not a signed AAB. A real domain, Android SDK/Studio, signing key, Play Console account, privacy policy, store listing, data-safety declarations, an operational account-deletion request process, real-device testing and Google's review are still required.

## Not yet a full commercial production platform
Not included: background music generation, professional multi-track editing, drag-and-drop trimming, transitions, subtitles, dubbing workflows, payment/credits, refunds, email verification/password reset, user account deletion endpoints, production-grade cloud storage/queue/database, moderation operations, backups, monitoring, formal security review, or actual Play Store publication. Do not launch publicly or charge users until these are built and tested.
