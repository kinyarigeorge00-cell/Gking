import type { CapacitorConfig } from '@capacitor/cli';

// The UI is bundled locally in the Android app. Configure public/app-config.js
// with the deployed HTTPS backend origin before building the Play Store version.
const config: CapacitorConfig = {
  appId: 'com.gkingstudio.ultimate',
  appName: 'Gking AI Movie Studio',
  webDir: 'public',
  android: { allowMixedContent: false }
};
export default config;
