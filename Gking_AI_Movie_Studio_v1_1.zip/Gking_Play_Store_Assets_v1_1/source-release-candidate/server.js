require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const { promisify } = require("util");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.warn("WARNING: Set JWT_SECRET to a long random value in .env before deployment.");
}
const secret = JWT_SECRET || "development-only-change-this-secret-before-deploying";
const dbPath = process.env.DATABASE_PATH || "./data/gking.sqlite";
fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
const db = new Database(dbPath);
const generatedDir = path.resolve(process.env.GENERATED_DIR || "./data/generated");
fs.mkdirSync(generatedDir, { recursive: true });
const execFileAsync = (file, args, options = {}) => new Promise((resolve, reject) => {
  const child = spawn(file, args, { ...options, stdio: ["ignore", "ignore", "pipe"] });
  let stderr = ""; child.stderr.on("data", chunk => { stderr += chunk.toString(); });
  child.on("error", reject); child.on("close", code => code === 0 ? resolve() : reject(new Error(`${file} failed (${code}): ${stderr.slice(-1800)}`)));
});
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  genre TEXT NOT NULL DEFAULT 'Drama',
  format TEXT NOT NULL DEFAULT 'Film',
  premise TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS characters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  project_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'Supporting character',
  age_description TEXT NOT NULL DEFAULT '',
  appearance TEXT NOT NULL DEFAULT '',
  personality TEXT NOT NULL DEFAULT '',
  wardrobe TEXT NOT NULL DEFAULT '',
  voice_notes TEXT NOT NULL DEFAULT '',
  reference_notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(project_id) REFERENCES projects(id)
);
CREATE TABLE IF NOT EXISTS account_deletion_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL,
  message TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  project_id INTEGER NOT NULL,
  kind TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'mock',
  status TEXT NOT NULL DEFAULT 'queued',
  input_json TEXT NOT NULL,
  result_json TEXT,
  error TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(project_id) REFERENCES projects(id)
);
`);
app.use(helmet({ contentSecurityPolicy: false }));
const allowedOrigins = new Set(["https://localhost", "capacitor://localhost", "http://localhost", ...(process.env.CORS_ORIGINS || "").split(",").map(x => x.trim()).filter(Boolean)]);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
  }
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 240, standardHeaders: true, legacyHeaders: false }));

const safeUser = (u) => ({ id: u.id, email: u.email, plan: u.plan });
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    if (!token) throw new Error("missing token");
    req.user = jwt.verify(token, secret);
    next();
  } catch {
    res.status(401).json({ error: "Please sign in to continue." });
  }
}
function issueToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, secret, { expiresIn: "7d" });
}

// Provider adapter boundary. The mock adapter lets you test the workflow;
// replace its methods with real vendor API calls once providers are selected.
const providers = {
  mock: {
    name: "Gking Demo Engine",
    async generate(kind, input) {
      await new Promise(resolve => setTimeout(resolve, 500));
      if (kind === "script") {
        const title = input.title || "Untitled Gking Film";
        return {
          title,
          logline: input.premise || "A story waiting to be told.",
          scenes: [
            { number: 1, heading: "OPENING", description: "Establish the world, lead character and central question.", dialogue: [] },
            { number: 2, heading: "THE TURN", description: "A discovery or decision changes the direction of the story.", dialogue: [] },
            { number: 3, heading: "THE CLIMAX", description: "The protagonist faces the central conflict.", dialogue: [] },
            { number: 4, heading: "RESOLUTION", description: "Show the consequences and emotional resolution.", dialogue: [] }
          ],
          note: "Demo output. Set TEXT_PROVIDER=openai and OPENAI_API_KEY to enable live AI screenplay writing."
        };
      }
      return {
        message: `${kind} job accepted in demo mode.`,
        prompt: input.prompt || "",
        productionStatus: "demo_only",
        note: "No real media was generated. Connect a media provider adapter to enable this feature."
      };
    }
  },
  openai: {
    name: "OpenAI text generation",
    async generate(kind, input) {
      if (kind !== "script") {
        throw new Error("The OpenAI adapter in this build is for screenplay text only. Image, video, audio and rendering providers still need separate integrations.");
      }
      const apiKey = process.env.OPENAI_API_KEY;
      if (!apiKey) throw new Error("OPENAI_API_KEY is missing. Add it to your server .env file.");
      const model = process.env.OPENAI_TEXT_MODEL || "gpt-6-luna";
      const prompt = [
        "You are the screenplay development engine for Gking, an AI movie studio.",
        "Create an original, practical screenplay treatment for the supplied project.",
        "Include: title, logline, genre and tone, target audience, main characters, beginning/middle/end, and 8-12 numbered scenes.",
        "For each scene provide a slugline, visual action, emotional beat, and sample dialogue when appropriate.",
        "Respect the chosen genre and format. For African/Kenyan stories, avoid stereotypes and use grounded, respectful cultural detail.",
        "Do not claim that video or other media has already been generated. Return readable Markdown.",
        `PROJECT TITLE: ${input.title || "Untitled"}`,
        `GENRE: ${input.genre || "Drama"}`,
        `FORMAT: ${input.format || "Film"}`,
        `STORY IDEA: ${input.premise || input.prompt || "Develop an original story."}`
      ].join("\n\n");
      const response = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          instructions: "You are a skilled screenwriter and story editor. Be vivid, original, coherent, and production-minded.",
          input: prompt
        })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const message = data && data.error && data.error.message ? data.error.message : `OpenAI API returned HTTP ${response.status}`;
        throw new Error(message);
      }
      const outputText = data.output_text || (data.output || [])
        .filter(item => item.type === "message")
        .flatMap(item => item.content || [])
        .filter(part => part.type === "output_text")
        .map(part => part.text)
        .join("\n");
      if (!outputText) throw new Error("The text provider returned no screenplay text.");
      return {
        title: input.title || "Untitled Gking Film",
        provider: "openai",
        model,
        productionStatus: "screenplay_generated",
        screenplay: outputText
      };
    }
  },
  openaiImage: {
    name: "OpenAI image generation",
    async generate(kind, input, jobId) {
      if (kind !== "image") {
        throw new Error("This image adapter only supports image jobs.");
      }
      const apiKey = process.env.OPENAI_API_KEY;
      if (!apiKey) throw new Error("OPENAI_API_KEY is missing. Add it to your server .env file.");
      const model = process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare";
      const quality = ["low", "medium", "high", "auto"].includes(input.options?.quality) ? input.options.quality : "medium";
      const size = ["1024x1024", "1536x1024", "1024x1536", "1536x864"].includes(input.options?.size) ? input.options.size : "1536x1024";
      const prompt = [
        "Create a polished cinematic concept image for a film production.",
        `Project title: ${input.title || "Untitled film"}.`,
        `Genre: ${input.genre || "Drama"}.`,
        `Story context: ${input.premise || "No additional story context provided"}.`,
        `Specific image request: ${input.prompt || "Create a key visual establishing shot for this story"}.`,
        "Aim for coherent composition, expressive lighting, production-ready detail, and no captions, watermarks, logos, or embedded text unless explicitly requested."
      ].join("\n");
      const response = await fetch("https://api.openai.com/v1/images/generations", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          prompt,
          size,
          quality,
          output_format: "png",
          n: 1,
          safety_identifier: `gking-user-${input.userId || "creator"}`
        })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const message = data && data.error && data.error.message ? data.error.message : `Image API returned HTTP ${response.status}`;
        throw new Error(message);
      }
      const encoded = data?.data?.[0]?.b64_json;
      if (!encoded) throw new Error("Image provider returned no image data.");
      const filename = `job-${jobId}.png`;
      const fullPath = path.join(generatedDir, filename);
      fs.writeFileSync(fullPath, Buffer.from(encoded, "base64"), { mode: 0o600 });
      return {
        provider: "openai",
        model,
        productionStatus: "image_generated",
        mimeType: "image/png",
        filename,
        imageEndpoint: `/api/jobs/${jobId}/image`,
        prompt,
        note: "Image generated. It is stored in the server's generated-assets directory."
      };
    }
  },
  googleVideo: {
    name: "Google Gemini Omni video generation",
    async generate(kind, input, jobId) {
      if (kind !== "video") throw new Error("The Google video adapter only supports video jobs.");
      const apiKey = process.env.GOOGLE_API_KEY;
      if (!apiKey) throw new Error("GOOGLE_API_KEY is missing. Add your Gemini API key to the server .env file.");
      const model = process.env.GOOGLE_VIDEO_MODEL || "gemini-omni-1.1-flash";
      const aspectRatio = ["16:9", "9:16"].includes(input.options?.aspectRatio) ? input.options.aspectRatio : "16:9";
      const resolution = ["360p", "720p", "1080p", "4k"].includes(input.options?.resolution) ? input.options.resolution : "720p";
      const prompt = [
        "Generate one cinematic video shot for the Gking movie project.",
        `Project title: ${input.title || "Untitled film"}.`,
        `Genre: ${input.genre || "Drama"}.`,
        `Story context: ${input.premise || "No additional story context provided"}.`,
        `Shot direction: ${input.prompt || "Create an establishing shot that introduces the setting and mood."}.`,
        "Use clear subject action, believable motion, intentional camera movement, consistent lighting and a coherent cinematic look. Avoid captions, watermarks, logos and embedded text unless specifically requested."
      ].join("\n\n");
      const apiInput = [];
      const referenceJobId = Number(input.options?.referenceImageJobId || 0);
      if (referenceJobId) {
        const refJob = db.prepare("SELECT * FROM jobs WHERE id=? AND user_id=? AND project_id=? AND kind='image' AND status='completed'")
          .get(referenceJobId, input.userId, input.projectId);
        if (!refJob || !refJob.result_json) throw new Error("Reference image job must be a completed image job in this project.");
        const ref = JSON.parse(refJob.result_json);
        if (ref.productionStatus !== "image_generated" || !ref.filename) throw new Error("The selected reference job does not contain a generated image.");
        const refPath = path.join(generatedDir, path.basename(ref.filename));
        if (!fs.existsSync(refPath)) throw new Error("Reference image file is missing from generated storage.");
        apiInput.push({ type: "image", data: fs.readFileSync(refPath).toString("base64"), mime_type: ref.mimeType || "image/png" });
        apiInput.push({ type: "text", text: `Use the supplied reference image as the visual starting point and preserve its key visual identity while animating the shot. ${prompt}` });
      } else {
        apiInput.push({ type: "text", text: prompt });
      }
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/interactions?key=${encodeURIComponent(apiKey)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          input: apiInput.length === 1 ? apiInput[0].text : apiInput,
          response_format: { type: "video", aspect_ratio: aspectRatio, resolution }
        }),
        signal: AbortSignal.timeout(Number(process.env.VIDEO_TIMEOUT_MS || 300000))
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const message = data?.error?.message || `Gemini video API returned HTTP ${response.status}`;
        throw new Error(message);
      }
      const videoPart = (data.steps || []).filter(step => step.type === "model_output")
        .flatMap(step => step.content || []).find(part => part.type === "video" && part.data);
      const encoded = data?.output_video?.data || videoPart?.data;
      if (!encoded) {
        const status = data.status ? ` (status: ${data.status})` : "";
        throw new Error(`Video provider returned no downloadable MP4${status}. Check model access and provider response.`);
      }
      const filename = `job-${jobId}.mp4`;
      fs.writeFileSync(path.join(generatedDir, filename), Buffer.from(encoded, "base64"), { mode: 0o600 });
      return {
        provider: "google",
        model,
        productionStatus: "video_generated",
        mimeType: "video/mp4",
        filename,
        videoEndpoint: `/api/jobs/${jobId}/video`,
        aspectRatio,
        resolution,
        prompt,
        providerInteractionId: data.id || null,
        note: "Video generated and stored in the server's generated-assets directory. Provider charges and limits apply."
      };
    }
  },
  openaiAudio: {
    name: "OpenAI text-to-speech",
    async generate(kind, input, jobId) {
      if (kind !== "audio") throw new Error("The speech adapter only supports audio jobs.");
      const apiKey = process.env.OPENAI_API_KEY;
      if (!apiKey) throw new Error("OPENAI_API_KEY is missing. Add it to the server .env file.");
      const text = String(input.prompt || input.premise || "").trim();
      if (!text) throw new Error("Enter the dialogue or narration text in the scene prompt before generating audio.");
      if (text.length > 4000) throw new Error("For this release, each speech clip is limited to 4,000 characters.");
      const voice = ["alloy","ash","ballad","coral","echo","fable","onyx","nova","sage","shimmer","verse"].includes(input.options?.voice) ? input.options.voice : "alloy";
      const model = process.env.OPENAI_TTS_MODEL || "gpt-4o-mini-tts";
      const response = await fetch("https://api.openai.com/v1/audio/speech", {
        method: "POST", headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model, voice, input: text, instructions: input.options?.instructions || "Speak clearly and naturally for a cinematic film. Do not add words that are not in the script.", response_format: "mp3" }),
        signal: AbortSignal.timeout(Number(process.env.AUDIO_TIMEOUT_MS || 120000))
      });
      if (!response.ok) { const err = await response.json().catch(() => ({})); throw new Error(err?.error?.message || `Speech API returned HTTP ${response.status}`); }
      const filename = `job-${jobId}.mp3`;
      fs.writeFileSync(path.join(generatedDir, filename), Buffer.from(await response.arrayBuffer()), { mode: 0o600 });
      return { provider: "openai", model, voice, productionStatus: "audio_generated", mimeType: "audio/mpeg", filename, audioEndpoint: `/api/jobs/${jobId}/audio`, text, note: "Speech audio generated. This adapter generates spoken dialogue/narration, not original background music." };
    }
  },
  ffmpegRender: {
    name: "FFmpeg movie assembly",
    async generate(kind, input, jobId) {
      if (kind !== "render") throw new Error("The FFmpeg adapter only supports render jobs.");
      const projectId = Number(input.projectId);
      const clips = db.prepare("SELECT j.id, j.result_json FROM jobs j WHERE j.project_id=? AND j.user_id=? AND j.kind='video' AND j.status='completed' ORDER BY j.id ASC").all(projectId, input.userId);
      const files = clips.map(j => { try { const r=JSON.parse(j.result_json || "{}"); return r.productionStatus === "video_generated" && r.filename ? path.join(generatedDir, path.basename(r.filename)) : null; } catch { return null; } }).filter(f => f && fs.existsSync(f));
      if (!files.length) throw new Error("No completed video clips were found in this project. Generate at least one real video scene first.");
      const tempDir = path.join(generatedDir, `render-${jobId}`); fs.mkdirSync(tempDir, { recursive: true });
      const normalized = [];
      try {
        for (let i=0; i<files.length; i++) {
          const out = path.join(tempDir, `clip-${String(i+1).padStart(4,"0")}.mp4`);
          await execFileAsync(process.env.FFMPEG_PATH || "ffmpeg", ["-y","-i",files[i],"-vf","scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=24,setsar=1","-an","-c:v","libx264","-preset","veryfast","-crf","23","-pix_fmt","yuv420p","-movflags","+faststart",out]);
          normalized.push(out);
        }
        const list = path.join(tempDir,"concat.txt");
        fs.writeFileSync(list, normalized.map(f => `file '${f.replace(/'/g, "'\\''")}'`).join("\n"));
        const filename = `job-${jobId}.mp4`; const output = path.join(generatedDir,filename);
        await execFileAsync(process.env.FFMPEG_PATH || "ffmpeg", ["-y","-f","concat","-safe","0","-i",list,"-c","copy","-movflags","+faststart",output]);
        return { provider: "ffmpeg", productionStatus: "movie_rendered", mimeType: "video/mp4", filename, videoEndpoint: `/api/jobs/${jobId}/video`, includedClips: files.length, note: "Assembled available generated clips in creation order. This release does not yet add transitions, subtitles, dialogue mixing or music." };
      } finally { fs.rmSync(tempDir,{recursive:true,force:true}); }
    }
  }
};
function providerFor(kind) {
  const envName = kind === "script" ? "TEXT_PROVIDER" :
    kind === "render" ? "RENDER_PROVIDER" : `${kind.toUpperCase()}_PROVIDER`;
  const configured = process.env[envName] || "mock";
  if (kind === "image" && configured === "openai") return "openaiImage";
  if (kind === "video" && configured === "google") return "googleVideo";
  if (kind === "audio" && configured === "openai") return "openaiAudio";
  if (kind === "render" && configured === "ffmpeg") return "ffmpegRender";
  return configured;
}
async function processJob(jobId) {
  const job = db.prepare("SELECT * FROM jobs WHERE id=?").get(jobId);
  if (!job) return;
  db.prepare("UPDATE jobs SET status='processing', updated_at=CURRENT_TIMESTAMP WHERE id=?").run(jobId);
  try {
    const providerName = job.provider;
    const provider = providers[providerName];
    if (!provider) throw new Error(`Provider '${providerName}' is not configured.`);
    const result = await provider.generate(job.kind, { ...JSON.parse(job.input_json), userId: job.user_id, projectId: job.project_id }, job.id);
    db.prepare("UPDATE jobs SET status='completed', result_json=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
      .run(JSON.stringify(result), jobId);
  } catch (e) {
    db.prepare("UPDATE jobs SET status='failed', error=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
      .run(String(e.message || e), jobId);
  }
}
function enqueue(userId, projectId, kind, input) {
  const provider = providerFor(kind);
  const result = db.prepare(
    "INSERT INTO jobs (user_id, project_id, kind, provider, input_json) VALUES (?, ?, ?, ?, ?)"
  ).run(userId, projectId, kind, provider, JSON.stringify(input));
  const id = Number(result.lastInsertRowid);
  setImmediate(() => processJob(id));
  return db.prepare("SELECT id, project_id, kind, provider, status, created_at FROM jobs WHERE id=?").get(id);
}

app.get("/api/health", (req, res) => res.json({
  app: "Gking Ultimate AI Movie Studio v1.0 Release Candidate",
  status: "ok",
  mode: "hybrid-cloud-ready",
  providers: {
    text: process.env.TEXT_PROVIDER || "mock",
    image: process.env.IMAGE_PROVIDER || "mock",
    video: process.env.VIDEO_PROVIDER || "mock",
    audio: process.env.AUDIO_PROVIDER || "mock",
    render: process.env.RENDER_PROVIDER || "mock"
  },
  productionMediaGeneration: ((process.env.IMAGE_PROVIDER === "openai" || process.env.AUDIO_PROVIDER === "openai") && Boolean(process.env.OPENAI_API_KEY)) || (process.env.VIDEO_PROVIDER === "google" && Boolean(process.env.GOOGLE_API_KEY))
}));

app.post("/api/account-deletion-requests", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const message = String(req.body.message || "").trim().slice(0, 2000);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid account email address." });
  db.prepare("INSERT INTO account_deletion_requests (email, message) VALUES (?, ?)").run(email, message);
  res.status(202).json({ ok: true, message: "Your deletion request has been submitted. The service operator must verify the request and complete deletion." });
});
app.post("/api/auth/register", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (password.length < 10) return res.status(400).json({ error: "Password must be at least 10 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)").run(email, hash);
    const user = db.prepare("SELECT id, email, plan FROM users WHERE id=?").get(info.lastInsertRowid);
    res.status(201).json({ token: issueToken(user), user: safeUser(user) });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "An account with this email already exists." });
    res.status(500).json({ error: "Could not create account." });
  }
});
app.post("/api/auth/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
  res.json({ token: issueToken(user), user: safeUser(user) });
});
app.get("/api/me", auth, (req, res) => {
  const user = db.prepare("SELECT id, email, plan, created_at FROM users WHERE id=?").get(req.user.id);
  if (!user) return res.status(404).json({ error: "Account not found." });
  res.json({ user });
});
app.post("/api/account/delete", auth, async (req, res) => {
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Your current password is required to delete this account." });
  const jobs = db.prepare("SELECT result_json FROM jobs WHERE user_id=?").all(user.id);
  for (const row of jobs) { try { const result=JSON.parse(row.result_json || "{}"); if (result.filename) { const filename=path.basename(result.filename); const file=path.join(generatedDir,filename); if (fs.existsSync(file)) fs.unlinkSync(file); } } catch {} }
  const remove = db.transaction(() => {
    db.prepare("DELETE FROM jobs WHERE user_id=?").run(user.id);
    db.prepare("DELETE FROM characters WHERE user_id=?").run(user.id);
    db.prepare("DELETE FROM projects WHERE user_id=?").run(user.id);
    db.prepare("DELETE FROM users WHERE id=?").run(user.id);
  });
  remove();
  res.json({ ok: true, message: "Account and associated project records were deleted." });
});
app.get("/api/projects", auth, (req, res) => {
  res.json({ projects: db.prepare("SELECT * FROM projects WHERE user_id=? ORDER BY updated_at DESC").all(req.user.id) });
});
app.post("/api/projects", auth, (req, res) => {
  const title = String(req.body.title || "").trim().slice(0, 120);
  const genre = String(req.body.genre || "Drama").slice(0, 50);
  const format = String(req.body.format || "Film").slice(0, 30);
  const premise = String(req.body.premise || "").slice(0, 5000);
  if (!title) return res.status(400).json({ error: "Project title is required." });
  const info = db.prepare("INSERT INTO projects (user_id, title, genre, format, premise) VALUES (?, ?, ?, ?, ?)")
    .run(req.user.id, title, genre, format, premise);
  res.status(201).json({ project: db.prepare("SELECT * FROM projects WHERE id=?").get(info.lastInsertRowid) });
});
app.get("/api/projects/:id", auth, (req, res) => {
  const project = db.prepare("SELECT * FROM projects WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!project) return res.status(404).json({ error: "Project not found." });
  const jobs = db.prepare("SELECT id, kind, provider, status, result_json, error, created_at FROM jobs WHERE project_id=? AND user_id=? ORDER BY id DESC")
    .all(project.id, req.user.id);
  res.json({ project, jobs: jobs.map(j => ({ ...j, result: j.result_json ? JSON.parse(j.result_json) : null, result_json: undefined })) });
});
app.patch("/api/projects/:id", auth, (req, res) => {
  const project = db.prepare("SELECT * FROM projects WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!project) return res.status(404).json({ error: "Project not found." });
  const title = req.body.title === undefined ? project.title : String(req.body.title).slice(0, 120);
  const premise = req.body.premise === undefined ? project.premise : String(req.body.premise).slice(0, 5000);
  const status = req.body.status === undefined ? project.status : String(req.body.status).slice(0, 30);
  db.prepare("UPDATE projects SET title=?, premise=?, status=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?")
    .run(title, premise, status, project.id, req.user.id);
  res.json({ project: db.prepare("SELECT * FROM projects WHERE id=?").get(project.id) });
});
app.get("/api/projects/:id/characters", auth, (req, res) => {
  const project = db.prepare("SELECT id FROM projects WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!project) return res.status(404).json({ error: "Project not found." });
  const characters = db.prepare("SELECT * FROM characters WHERE project_id=? AND user_id=? ORDER BY name COLLATE NOCASE").all(project.id, req.user.id);
  res.json({ characters });
});
app.post("/api/projects/:id/characters", auth, (req, res) => {
  const project = db.prepare("SELECT id FROM projects WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!project) return res.status(404).json({ error: "Project not found." });
  const name = String(req.body.name || "").trim().slice(0, 100);
  if (!name) return res.status(400).json({ error: "Character name is required." });
  const fields = {
    role: String(req.body.role || "Supporting character").slice(0, 80),
    age_description: String(req.body.age_description || "").slice(0, 120),
    appearance: String(req.body.appearance || "").slice(0, 2000),
    personality: String(req.body.personality || "").slice(0, 1500),
    wardrobe: String(req.body.wardrobe || "").slice(0, 1500),
    voice_notes: String(req.body.voice_notes || "").slice(0, 1000),
    reference_notes: String(req.body.reference_notes || "").slice(0, 1500)
  };
  const result = db.prepare(`INSERT INTO characters (user_id, project_id, name, role, age_description, appearance, personality, wardrobe, voice_notes, reference_notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(req.user.id, project.id, name, fields.role, fields.age_description, fields.appearance, fields.personality, fields.wardrobe, fields.voice_notes, fields.reference_notes);
  res.status(201).json({ character: db.prepare("SELECT * FROM characters WHERE id=?").get(result.lastInsertRowid) });
});
app.patch("/api/characters/:id", auth, (req, res) => {
  const current = db.prepare("SELECT * FROM characters WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!current) return res.status(404).json({ error: "Character not found." });
  const value = (key, max) => req.body[key] === undefined ? current[key] : String(req.body[key]).slice(0, max);
  const name = value("name", 100).trim();
  if (!name) return res.status(400).json({ error: "Character name is required." });
  db.prepare(`UPDATE characters SET name=?, role=?, age_description=?, appearance=?, personality=?, wardrobe=?, voice_notes=?, reference_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?`)
    .run(name, value("role",80), value("age_description",120), value("appearance",2000), value("personality",1500), value("wardrobe",1500), value("voice_notes",1000), value("reference_notes",1500), current.id, req.user.id);
  res.json({ character: db.prepare("SELECT * FROM characters WHERE id=?").get(current.id) });
});
app.delete("/api/characters/:id", auth, (req, res) => {
  const result = db.prepare("DELETE FROM characters WHERE id=? AND user_id=?").run(Number(req.params.id), req.user.id);
  if (!result.changes) return res.status(404).json({ error: "Character not found." });
  res.json({ ok: true });
});
app.post("/api/projects/:id/generate", auth, (req, res) => {
  const project = db.prepare("SELECT * FROM projects WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!project) return res.status(404).json({ error: "Project not found." });
  const kind = String(req.body.kind || "script");
  if (!["script", "image", "video", "audio", "render"].includes(kind)) return res.status(400).json({ error: "Unsupported generation type." });
  const options = req.body.options && typeof req.body.options === "object" ? { ...req.body.options } : {};
  const characterId = Number(options.characterId || 0);
  let character = null;
  if (characterId) {
    character = db.prepare("SELECT * FROM characters WHERE id=? AND project_id=? AND user_id=?").get(characterId, project.id, req.user.id);
    if (!character) return res.status(400).json({ error: "Selected character does not belong to this project." });
  }
  const characterDescription = character ? [
    `Character identity to preserve: ${character.name}.`, `Role: ${character.role}.`,
    character.age_description && `Age / life stage: ${character.age_description}.`,
    character.appearance && `Fixed visual appearance: ${character.appearance}.`,
    character.personality && `Personality: ${character.personality}.`,
    character.wardrobe && `Wardrobe: ${character.wardrobe}.`,
    character.voice_notes && `Voice notes: ${character.voice_notes}.`,
    character.reference_notes && `Continuity notes: ${character.reference_notes}.`,
    "Maintain the same recognizable face, skin tone, hair, body proportions and signature details in every shot. Do not redesign this character unless the scene explicitly requires a costume change."
  ].filter(Boolean).join("\n") : "";
  const userPrompt = String(req.body.prompt || project.premise || "").slice(0, 5000);
  const input = {
    title: project.title,
    premise: project.premise,
    genre: project.genre,
    format: project.format,
    prompt: [userPrompt, characterDescription].filter(Boolean).join("\n\n"),
    character: character ? { id: character.id, name: character.name, role: character.role, appearance: character.appearance, wardrobe: character.wardrobe, personality: character.personality, voice_notes: character.voice_notes, reference_notes: character.reference_notes } : null,
    options: { ...options, characterId: character ? character.id : null }
  };
  const job = enqueue(req.user.id, project.id, kind, input);
  res.status(202).json({ job, message: "Generation job queued. In this starter, outputs are demo placeholders until a real provider is connected." });
});
app.get("/api/jobs/:id/image", auth, (req, res) => {
  const job = db.prepare("SELECT * FROM jobs WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!job || job.status !== "completed" || !job.result_json) return res.status(404).json({ error: "Generated image not found." });
  let result;
  try { result = JSON.parse(job.result_json); } catch { return res.status(404).json({ error: "Image result is unavailable." }); }
  if (result.productionStatus !== "image_generated" || !result.filename) return res.status(404).json({ error: "This job has no generated image." });
  const safeName = path.basename(result.filename);
  const fullPath = path.join(generatedDir, safeName);
  if (!fs.existsSync(fullPath)) return res.status(404).json({ error: "Image file is missing from storage." });
  res.setHeader("Content-Type", result.mimeType || "image/png");
  res.setHeader("Cache-Control", "private, max-age=3600");
  res.sendFile(fullPath);
});
app.get("/api/jobs/:id/video", auth, (req, res) => {
  const job = db.prepare("SELECT * FROM jobs WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!job || job.status !== "completed" || !job.result_json) return res.status(404).json({ error: "Generated video not found." });
  let result;
  try { result = JSON.parse(job.result_json); } catch { return res.status(404).json({ error: "Video result is unavailable." }); }
  if (!(["video_generated", "movie_rendered"].includes(result.productionStatus)) || !result.filename) return res.status(404).json({ error: "This job has no generated video." });
  const safeName = path.basename(result.filename);
  const fullPath = path.join(generatedDir, safeName);
  if (!fs.existsSync(fullPath)) return res.status(404).json({ error: "Video file is missing from storage." });
  res.setHeader("Content-Type", "video/mp4");
  res.setHeader("Cache-Control", "private, max-age=3600");
  res.setHeader("Content-Disposition", `inline; filename="${safeName}"`);
  res.sendFile(fullPath);
});
app.get("/api/jobs/:id/audio", auth, (req, res) => {
  const job = db.prepare("SELECT * FROM jobs WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!job || job.status !== "completed" || !job.result_json) return res.status(404).json({ error: "Generated audio not found." });
  let result; try { result = JSON.parse(job.result_json); } catch { return res.status(404).json({ error: "Audio result is unavailable." }); }
  if (result.productionStatus !== "audio_generated" || !result.filename) return res.status(404).json({ error: "This job has no generated audio." });
  const fullPath = path.join(generatedDir, path.basename(result.filename));
  if (!fs.existsSync(fullPath)) return res.status(404).json({ error: "Audio file is missing from storage." });
  res.setHeader("Content-Type", result.mimeType || "audio/mpeg"); res.setHeader("Cache-Control", "private, max-age=3600");
  res.setHeader("Content-Disposition", `inline; filename="${path.basename(result.filename)}"`); res.sendFile(fullPath);
});
app.get("/api/jobs/:id", auth, (req, res) => {
  const job = db.prepare("SELECT * FROM jobs WHERE id=? AND user_id=?").get(Number(req.params.id), req.user.id);
  if (!job) return res.status(404).json({ error: "Job not found." });
  res.json({ job: { ...job, input: JSON.parse(job.input_json), result: job.result_json ? JSON.parse(job.result_json) : null, input_json: undefined, result_json: undefined } });
});
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Gking Studio running at http://localhost:${PORT}`));
