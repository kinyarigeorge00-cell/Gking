# Gking — next steps to Google Play

This package combines the current source release candidate with draft store graphics and listing copy. It is not a built or published app.

1. Deploy the backend and replace the placeholder HTTPS API origin in `source-release-candidate/public/app-config.js`.
2. Test every provider integration with real credentials, account ownership, error handling, rate limits and cost controls.
3. On a computer with internet access, Node.js 20+, Android Studio and Android SDK, install dependencies and run the Capacitor Android commands in the source README.
4. Configure the final application ID, icon/adaptive icon, splash screen, version code and signing key.
5. Build and test a signed `.aab` on real Android devices.
6. Complete Play Console declarations, content rating, target audience, data safety, privacy policy, support contact and working account deletion.
7. Upload to a testing track, resolve review/test issues, and submit for production review.

Never place AI API secrets in app JavaScript. Keep them on the server. Do not share your Play Console password or signing key.
