# Store asset notes

- `feature-graphic-1024x500.png`: draft Google Play feature graphic.
- `../icons/play-store-icon-512.png`: 512×512 PNG icon draft.
- Other icon PNGs are convenience sizes for previews/PWA; Android adaptive icon needs foreground and a separately configured background.

Review the assets at full size and replace them if desired before submission. These are launch-preparation assets, not a signed Android app.
